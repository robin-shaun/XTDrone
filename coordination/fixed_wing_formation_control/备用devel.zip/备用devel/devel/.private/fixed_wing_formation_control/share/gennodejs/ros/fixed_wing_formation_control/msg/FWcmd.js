// Auto-generated. Do not edit!

// (in-package fixed_wing_formation_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class FWcmd {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cmd_mode = null;
      this.pitch_angle_sp = null;
      this.yaw_angle_sp = null;
      this.roll_angle_sp = null;
      this.att_sp_quater = null;
      this.throttle_sp = null;
    }
    else {
      if (initObj.hasOwnProperty('cmd_mode')) {
        this.cmd_mode = initObj.cmd_mode
      }
      else {
        this.cmd_mode = '';
      }
      if (initObj.hasOwnProperty('pitch_angle_sp')) {
        this.pitch_angle_sp = initObj.pitch_angle_sp
      }
      else {
        this.pitch_angle_sp = 0.0;
      }
      if (initObj.hasOwnProperty('yaw_angle_sp')) {
        this.yaw_angle_sp = initObj.yaw_angle_sp
      }
      else {
        this.yaw_angle_sp = 0.0;
      }
      if (initObj.hasOwnProperty('roll_angle_sp')) {
        this.roll_angle_sp = initObj.roll_angle_sp
      }
      else {
        this.roll_angle_sp = 0.0;
      }
      if (initObj.hasOwnProperty('att_sp_quater')) {
        this.att_sp_quater = initObj.att_sp_quater
      }
      else {
        this.att_sp_quater = new geometry_msgs.msg.Quaternion();
      }
      if (initObj.hasOwnProperty('throttle_sp')) {
        this.throttle_sp = initObj.throttle_sp
      }
      else {
        this.throttle_sp = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FWcmd
    // Serialize message field [cmd_mode]
    bufferOffset = _serializer.string(obj.cmd_mode, buffer, bufferOffset);
    // Serialize message field [pitch_angle_sp]
    bufferOffset = _serializer.float64(obj.pitch_angle_sp, buffer, bufferOffset);
    // Serialize message field [yaw_angle_sp]
    bufferOffset = _serializer.float64(obj.yaw_angle_sp, buffer, bufferOffset);
    // Serialize message field [roll_angle_sp]
    bufferOffset = _serializer.float64(obj.roll_angle_sp, buffer, bufferOffset);
    // Serialize message field [att_sp_quater]
    bufferOffset = geometry_msgs.msg.Quaternion.serialize(obj.att_sp_quater, buffer, bufferOffset);
    // Serialize message field [throttle_sp]
    bufferOffset = _serializer.float64(obj.throttle_sp, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FWcmd
    let len;
    let data = new FWcmd(null);
    // Deserialize message field [cmd_mode]
    data.cmd_mode = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [pitch_angle_sp]
    data.pitch_angle_sp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [yaw_angle_sp]
    data.yaw_angle_sp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [roll_angle_sp]
    data.roll_angle_sp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [att_sp_quater]
    data.att_sp_quater = geometry_msgs.msg.Quaternion.deserialize(buffer, bufferOffset);
    // Deserialize message field [throttle_sp]
    data.throttle_sp = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.cmd_mode);
    return length + 68;
  }

  static datatype() {
    // Returns string type for a message object
    return 'fixed_wing_formation_control/FWcmd';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '62f17a12955286ad07282b54f80aad4a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #固定翼控制指令的期望值		
    string cmd_mode
    
    float64 pitch_angle_sp
    
    float64 yaw_angle_sp
    
    float64 roll_angle_sp
    
    geometry_msgs/Quaternion att_sp_quater #姿态四元数，只能在外面弄下旋转矩阵了
    
    float64 throttle_sp
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FWcmd(null);
    if (msg.cmd_mode !== undefined) {
      resolved.cmd_mode = msg.cmd_mode;
    }
    else {
      resolved.cmd_mode = ''
    }

    if (msg.pitch_angle_sp !== undefined) {
      resolved.pitch_angle_sp = msg.pitch_angle_sp;
    }
    else {
      resolved.pitch_angle_sp = 0.0
    }

    if (msg.yaw_angle_sp !== undefined) {
      resolved.yaw_angle_sp = msg.yaw_angle_sp;
    }
    else {
      resolved.yaw_angle_sp = 0.0
    }

    if (msg.roll_angle_sp !== undefined) {
      resolved.roll_angle_sp = msg.roll_angle_sp;
    }
    else {
      resolved.roll_angle_sp = 0.0
    }

    if (msg.att_sp_quater !== undefined) {
      resolved.att_sp_quater = geometry_msgs.msg.Quaternion.Resolve(msg.att_sp_quater)
    }
    else {
      resolved.att_sp_quater = new geometry_msgs.msg.Quaternion()
    }

    if (msg.throttle_sp !== undefined) {
      resolved.throttle_sp = msg.throttle_sp;
    }
    else {
      resolved.throttle_sp = 0.0
    }

    return resolved;
    }
};

module.exports = FWcmd;
