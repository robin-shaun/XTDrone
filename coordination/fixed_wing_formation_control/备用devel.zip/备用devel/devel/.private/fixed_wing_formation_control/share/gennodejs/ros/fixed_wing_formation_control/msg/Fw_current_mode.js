// Auto-generated. Do not edit!

// (in-package fixed_wing_formation_control.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Fw_current_mode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.planeID = null;
      this.mode = null;
    }
    else {
      if (initObj.hasOwnProperty('planeID')) {
        this.planeID = initObj.planeID
      }
      else {
        this.planeID = 0;
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Fw_current_mode
    // Serialize message field [planeID]
    bufferOffset = _serializer.uint16(obj.planeID, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Fw_current_mode
    let len;
    let data = new Fw_current_mode(null);
    // Deserialize message field [planeID]
    data.planeID = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 3;
  }

  static datatype() {
    // Returns string type for a message object
    return 'fixed_wing_formation_control/Fw_current_mode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '756753c5e2c2b3f6d3413192d8ae1c59';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint16 planeID
    
    uint8 mode
    
    uint8 FW_IN_IDEL = 0 
    
    uint8 FW_IN_TAKEOFF = 1
    
    uint8 FW_IN_LANDING = 2
    
    uint8 FW_IN_FORMATION = 3
    
    uint8 FW_IN_PROTECT = 4
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Fw_current_mode(null);
    if (msg.planeID !== undefined) {
      resolved.planeID = msg.planeID;
    }
    else {
      resolved.planeID = 0
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    return resolved;
    }
};

// Constants for message
Fw_current_mode.Constants = {
  FW_IN_IDEL: 0,
  FW_IN_TAKEOFF: 1,
  FW_IN_LANDING: 2,
  FW_IN_FORMATION: 3,
  FW_IN_PROTECT: 4,
}

module.exports = Fw_current_mode;
